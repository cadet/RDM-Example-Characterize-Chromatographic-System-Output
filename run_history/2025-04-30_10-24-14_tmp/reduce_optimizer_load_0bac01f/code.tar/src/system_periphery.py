# ---
# jupyter:
#   jupytext:
#     formats: py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.7
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Model System Periphery
#
# Show Foto
#
# Show Abstraction
#
# Show Model
#
#
# Fit Parameters
#
# Missing:
# - Data
# - Fotos
